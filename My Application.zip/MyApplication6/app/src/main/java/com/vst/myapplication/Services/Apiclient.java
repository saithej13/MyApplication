package com.vst.myapplication.Services;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.vst.myapplication.dataObject.farmerDO;

import org.json.JSONArray;
import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Url;

public interface Apiclient {
    @POST("webservices/api/Scan/Login")
    Call<JsonObject> Login(@Body JsonObject data);
    @POST("webservices/api/Scan/AllOrders")
    Call<JsonArray> loadOrders(@Body JsonObject data);
    @POST
    Call<JsonArray> isValidImei(@Url String url, @Body JsonArray data);
    @POST
    Call<String> SaveImei(@Url String url, @Body JsonObject data);
    @POST("farmers.php/{apikey}")
    Call<JSONObject> getfarmercode(@Body farmerDO data, @Path("apikey") String apikey);
    @POST("farmers.php/{apikey}")
    Call<JSONArray> getfarmersdata(@Path("apikey") String apikey);
}
