package com.vst.myapplication.Services;

import android.util.Log;

import androidx.lifecycle.MutableLiveData;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.vst.myapplication.dataObject.farmerDO;

import org.json.JSONArray;
import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProjectRepository {
    Apiclient apiClient = AppModule.getClient().create(Apiclient.class);
    public MutableLiveData<JsonObject> login(JsonObject payload) {
        Log.d("URL","Login Request-->"+payload);
        final MutableLiveData<JsonObject> data = new MutableLiveData<>();

        apiClient.Login(payload).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                Log.d("URL", "Login Request-->" + payload);
                if (response.isSuccessful()) {
                    data.setValue(response.body());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Log.d("Login", "payload Failed-->" + t.getMessage());
                data.setValue(null);
            }
        });
        return data;
    }
    public MutableLiveData<JSONObject> InsertFarmer(farmerDO payload) {
        Log.d("URL","getFarmerbycode Request-->"+payload);
        final MutableLiveData<JSONObject> data = new MutableLiveData<>();

        apiClient.getfarmercode(payload,"1").enqueue(new Callback<JSONObject>() {
            @Override
            public void onResponse(Call<JSONObject> call, Response<JSONObject> response) {
                Log.d("URL", "getFarmerbycode Request-->" + payload);
                if (response.isSuccessful()) {
                    data.setValue(response.body());
                }
            }

            @Override
            public void onFailure(Call<JSONObject> call, Throwable t) {
                Log.d("Log", "getFarmerbycode payload Failed-->" + t.getMessage());
                data.setValue(null);
            }
        });
        return data;
    }
    public MutableLiveData<JSONArray> getfarmers() {
        final MutableLiveData<JSONArray> data = new MutableLiveData<>();

        apiClient.getfarmersdata("4").enqueue(new Callback<JSONArray>() {
            @Override
            public void onResponse(Call<JSONArray> call, Response<JSONArray> response) {
                if (response.isSuccessful()) {
                    data.setValue(response.body());
                }
            }

            @Override
            public void onFailure(Call<JSONArray> call, Throwable t) {
                Log.d("Log", "getFarmerbycode payload Failed-->" + t.getMessage());
                data.setValue(null);
            }
        });
        return data;
    }
}
