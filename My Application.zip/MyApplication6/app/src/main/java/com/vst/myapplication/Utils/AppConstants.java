package com.vst.myapplication.Utils;

public class AppConstants {

//    public static final String BASE_URL="http://localhost//";
//    public static final String BASE_URL="http://10.20.53.104/";
    public static final String BASE_URL="http://priyamilk.com/dairyapp/";
}
