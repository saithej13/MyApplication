const Service = require('node-windows').Service

const svc = new Service({
    name:"nodemssql",
    description:"node mssql api service",
    script:"D:\\API\\api.js"
});

svc.on('install',function(){
    svc.start()
});

svc.install();